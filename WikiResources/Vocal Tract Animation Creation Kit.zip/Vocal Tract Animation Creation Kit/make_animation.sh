#!/bin/bash

if [ $# -eq 1 ]; then
	NAME="$1"
else
	NAME="Output_Animation"
fi

cp frame05.png frame06.png
cp frame05.png frame07.png
cp frame05.png frame08.png
cp frame05.png frame09.png
cp frame05.png frame10.png
cp frame05.png frame11.png
cp frame05.png frame12.png
cp frame05.png frame13.png
cp frame05.png frame14.png
cp frame04.png frame15.png
cp frame03.png frame16.png
cp frame02.png frame17.png
cp frame01.png frame18.png
cp frame01.png frame19.png
cp frame01.png frame20.png
cp frame01.png frame21.png

ffmpeg -framerate 10 -i frame%02d.png  -c:v libx264 -r 30 -pix_fmt yuv420p $NAME.mp4

rm frame06.png
rm frame07.png
rm frame08.png
rm frame09.png
rm frame10.png
rm frame11.png
rm frame12.png
rm frame13.png
rm frame14.png
rm frame15.png
rm frame16.png
rm frame17.png
rm frame18.png
rm frame19.png
rm frame20.png
rm frame21.png